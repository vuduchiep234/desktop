// Cac thanh phan cua html chay xong roi moi chay JQuery
$(document).ready(function() {
	
	
});